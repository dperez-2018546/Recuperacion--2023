'use strict'

const express = require('express');
const app = express(); 
const productRoutes = require('../src/games/games.routes');
const port = process.env.PORT || 3200; 
const cors = require('cors')

app.use(express.urlencoded({extended: false})); 
app.use(express.json());
app.use(cors())      
app.use('/games', gamesRoutes);

exports.initServer = ()=>{
    app.listen(port);
    console.log(`server http running in port ${port}`) 
}