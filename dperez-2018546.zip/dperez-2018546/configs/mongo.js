'use strict' 
const mongoose = require('mongoose');

exports.connect = async()=>{
    try{
        const uriMongo = '';
        await mongoose.connect(uriMongo);
        console.log('conected')
    }catch(err){
        console.log(err)  
    }
}