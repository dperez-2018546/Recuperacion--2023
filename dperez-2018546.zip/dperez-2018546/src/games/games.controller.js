'use strict'

const Product = require('./games.model');
const fs = require('fs')
const path = require('path')

exports.test = (req, res)=>{
    res.send({message: 'funcionando'});
}

exports.addGame = async(req, res)=>{
    try{
        let data = req.body;
        await newGame.save();
        return res.status(201).send({message: 'game added'});
    }catch(err){
        console.error(err);
        return res.status(500).send({message: 'error adding game'});
    }
}

exports.getGame = async(req, res)=>{
    try{
        let gameId = req.params.id;
        let game = await Game.findOne({_id: gameId});
        if(!game) return res.status(404).send({message: 'game nt found'});
        return res.send({mesasge: 'game found', game});
    }catch(err){
        console.error(err);
        return res.status(500).send({message: 'error getting gane'});
    }
}

exports.updateGame = async(req, res)=>{
    try{
        let productId = req.params.id;
        let data = req.body;
        let existGame = await Game.findOne({_id: data.Game});
        if(!existGame) return res.status(404).send({message: 'game not found'});
        let updatedGame = await Product.findOneAndUpdate(
            {_id: gameId},
            data,
            {new: true}
        ).populate('game')
        if(!updatedGame) return res.send({message: 'game not found'});
        return res.send({message: 'game updated', updatedGame});
    }catch(err){
        console.error(err);
        return res.status(500).send({message: 'error updating game'});
    }
}


exports.delete = async(req, res)=>{
    try{
        let idGame = req.params.id;
        let deletedGame = await Game.findOneAndDelete({_id: idGame});
        if(!deletedGame) return res.status(404).send({message: 'game not found'});
        return res.send({message: 'game deleted'})
    }catch(err){
        console.error(err);
        return res.status(500).send({message: 'error deleting'});
    }
}