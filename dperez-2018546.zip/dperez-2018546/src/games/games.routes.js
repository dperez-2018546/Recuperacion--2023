'use strict'

const express = require('express');
const api = express.Router();

const gameController = require('./games.controller');
const connectMultiparty = require('connect-multiparty');
const upload = connectMultiparty({uploadDir: './uploads/games'})

api.get('/test', gameController.test);
api.post('/add', gameController.addGame);
api.get('/get', gameController.getGames);
api.put('/update/:id', gameController.updateGame);
api.delete('/delete/:id', gameController.delete);
module.exports = api;