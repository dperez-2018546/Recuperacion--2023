'use strict'

const mongoose = require('mongoose');

const productSchema = mongoose.Schema({
    name: String,
    desctiption: Number,
});

module.exports = mongoose.model('Games', productSchema);